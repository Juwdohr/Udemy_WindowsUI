﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsUI
{
    public partial class Page1 : UserControl
    {
        #region properties

        #endregion

        #region variables

        #endregion

        #region init and load

        public Page1()
        {
            InitializeComponent();
        }

        private void Page1_Load(object sender, EventArgs e)
        {
            foreach(Control ctl in this.Controls)
            {
                ctl.MouseDown += new MouseEventHandler(base_MouseDown);
            }


            RefreshLabels(new object(), new EventArgs());

            GlobalConfig.LanguageChanged += new EventHandler(RefreshLabels);
        }

        private void RefreshLabels(object sender, EventArgs e)
        {
            nameLabel.Text = Phrases.GetPhrase("PAGE1");
        }

        private void base_MouseDown(object sender, MouseEventArgs e)
        {
            base.OnMouseDown(e);
        }

        #endregion

        #region button clicks

        #endregion
    }
}
